ano_atual = 2024
ano_nascimeto = int(input("QUAL O ANO QUE VOCÊ NASCEU?"))


idade = ano_atual - ano_nascimeto

print("você tem "+str(idade)+" anos")